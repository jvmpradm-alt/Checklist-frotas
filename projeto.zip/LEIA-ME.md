# Checklist Frota (APK Android)

App de inspeção pré-uso dos veículos: dados do colaborador, 7 fotos obrigatórias,
27 itens C/NC, até 3 avarias e relatório em PDF enviado ao WhatsApp corporativo.
Funciona sem internet.

## Onde mexer
Tudo o que é configuração fica no início do script de `app/src/main/assets/www/index.html`,
no bloco `CONFIGURAÇÃO (edite aqui)`:

- `WHATSAPP_CORPORATIVO`: número que recebe os checklists (DDI + DDD + número, só dígitos).
- `ITENS`: itens de inspeção. Itens com `,1` no final são críticos (NC bloqueia o veículo).
- `FOTOS`: fotos obrigatórias.
- `FUNCOES`: funções do colaborador.

Salve a alteração no GitHub (botão "Commit changes"). Em uns 4 minutos
uma nova versão aparece em **Releases**, pronta para baixar.

## Instalar nos celulares
1. Abra **Releases** (lado direito da página do repositório) e baixe o `.apk` mais recente.
2. Envie o arquivo para os celulares da equipe.
3. No celular, toque no arquivo e permita "instalar apps desta fonte".

Versões novas instalam por cima da anterior, sem perder o histórico.

## Segurança
A chave de assinatura (`keystore/frota.jks`) está no repositório para o GitHub
conseguir assinar o app. Mantenha o repositório **privado**. Não apague esse arquivo:
sem ele, as próximas versões não instalam por cima e cada celular precisaria desinstalar o app.
