package com.frota.checklist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int REQ_FOTO = 42;
    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private Uri fotoUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF0B5F73);
        limparPasta(new File(getCacheDir(), "fotos"));

        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                return abrirCamera(cb, p);
            }
        });
        web.addJavascriptInterface(new Ponte(), "Android");
        web.loadUrl("file:///android_asset/www/index.html");
    }

    /* Abre direto a câmera: foto sempre tirada na hora, sem escolher da galeria */
    private boolean abrirCamera(ValueCallback<Uri[]> cb, WebChromeClient.FileChooserParams p) {
        if (fileCb != null) fileCb.onReceiveValue(null);
        fileCb = cb;
        try {
            File dir = new File(getCacheDir(), "fotos");
            dir.mkdirs();
            File f = File.createTempFile("foto_", ".jpg", dir);
            fotoUri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent cam = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cam.putExtra(MediaStore.EXTRA_OUTPUT, fotoUri);
            cam.setClipData(ClipData.newRawUri("foto", fotoUri));
            cam.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(cam, REQ_FOTO);
            return true;
        } catch (ActivityNotFoundException e) {
            try {
                fotoUri = null;
                startActivityForResult(p.createIntent(), REQ_FOTO);
                return true;
            } catch (Exception e2) {
                fileCb = null;
                return false;
            }
        } catch (Exception e) {
            fileCb = null;
            return false;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_FOTO || fileCb == null) return;
        Uri[] r = null;
        if (res == RESULT_OK) {
            if (fotoUri != null) r = new Uri[]{fotoUri};
            else if (data != null && data.getData() != null) r = new Uri[]{data.getData()};
        }
        fileCb.onReceiveValue(r);
        fileCb = null;
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.voltarApp && window.voltarApp()) ? '1' : '0'", v -> {
            if ("\"1\"".equals(v)) return;
            new AlertDialog.Builder(this)
                    .setTitle("Sair do checklist?")
                    .setMessage("O que já foi preenchido fica salvo e volta quando você abrir o app.")
                    .setPositiveButton("Sair", (d, w) -> finish())
                    .setNegativeButton("Continuar", null)
                    .show();
        });
    }

    public class Ponte {
        @JavascriptInterface
        public void sharePdf(String b64, String nome, String fone, String texto) {
            runOnUiThread(() -> compartilhar(b64, nome, fone, texto));
        }

        @JavascriptInterface
        public void savePdf(String b64, String nome) {
            runOnUiThread(() -> salvar(b64, nome));
        }
    }

    private void compartilhar(String b64, String nome, String fone, String texto) {
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            File dir = new File(getCacheDir(), "pdf");
            dir.mkdirs();
            limparPasta(dir);
            File f = new File(dir, nome);
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(bytes);
            }
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", f);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_STREAM, uri);
            i.putExtra(Intent.EXTRA_TEXT, texto);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

            String num = fone == null ? "" : fone.replaceAll("\\D", "");
            if (!num.isEmpty()) {
                // Abre direto a conversa do número corporativo com o PDF anexado
                for (String pkg : new String[]{"com.whatsapp.w4b", "com.whatsapp"}) {
                    if (!instalado(pkg)) continue;
                    Intent w = new Intent(i);
                    w.setPackage(pkg);
                    w.putExtra("jid", num + "@s.whatsapp.net");
                    try {
                        startActivity(w);
                        return;
                    } catch (Exception ignored) {
                    }
                }
                aviso("WhatsApp não encontrado. Escolha outro app para enviar.");
            }
            startActivity(Intent.createChooser(i, "Enviar checklist"));
        } catch (Exception e) {
            aviso("Não foi possível compartilhar: " + e.getMessage());
        }
    }

    private void salvar(String b64, String nome) {
        try {
            byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nome);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Checklist Frota");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    o.write(bytes);
                }
                aviso("PDF salvo em Downloads/Checklist Frota");
            } else {
                File dir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                if (dir == null) dir = getFilesDir();
                dir.mkdirs();
                File f = new File(dir, nome);
                try (FileOutputStream o = new FileOutputStream(f)) {
                    o.write(bytes);
                }
                aviso("PDF salvo em " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            aviso("Não foi possível salvar: " + e.getMessage());
        }
    }

    private boolean instalado(String pkg) {
        try {
            getPackageManager().getPackageInfo(pkg, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    private void aviso(String t) {
        Toast.makeText(this, t, Toast.LENGTH_LONG).show();
    }

    private static void limparPasta(File d) {
        File[] fs = d.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }
}
